package com.lexisnexis.ui.clustercounts;

public class ClusterCountsRow {
	
	private String incluster;
	
	private String numberOfClusters;

	public String getIncluster() {
		return incluster;
	}

	public void setIncluster(String incluster) {
		this.incluster = incluster;
	}

	public String getNumberOfClusters() {
		return numberOfClusters;
	}

	public void setNumberOfClusters(String numberOfClusters) {
		this.numberOfClusters = numberOfClusters;
	}
	
}
